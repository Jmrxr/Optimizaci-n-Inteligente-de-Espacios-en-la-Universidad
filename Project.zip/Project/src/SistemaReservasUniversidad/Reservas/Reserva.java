package SistemaReservasUniversidad.Reservas;

import SistemaReservasUniversidad.Usuarios.Usuario;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JOptionPane;

public class Reserva {

    //Atributos
    private int identificador;
    private Date fechaInicio;
    private Date fechaFin;
    private Usuario usuario;//Atributos para guardar el usuario que realizo la reserva

    //Lista almacenar reservas
    public static ArrayList<Reserva> listaReservas = new ArrayList<>();

    //Constructor
    public Reserva(int identificador, Date fechaInicio, Date fechaFin, Usuario usuario) {
        this.identificador = identificador;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.usuario = usuario;//Establecer el usuario que realizó la reserva
        listaReservas.add(this);//Agregar la reserva a la lista
    }

    //Método para registrar reserva
    public static void registrar(int identificador, Date fechaInicio, Date fechaFin, Usuario usuario) {
        //Crear una nueva reserva y agregarla a lista
        Reserva nuevaReserva = new Reserva(identificador, fechaInicio, fechaFin, usuario);
        listaReservas.add(nuevaReserva);

    }

    //Método publicar reserva
    public static void publicar() {
        String mensaje = "Lista reservas\n";
        //Patrón de recorrido total
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm a");
        for (Reserva reserva : listaReservas) {
            String fechaInicioFormateada = sdf.format(reserva.fechaInicio);
            String fechaFinFormateada = sdf.format(reserva.fechaFin);
            mensaje += "Aula: " + reserva.identificador + " - Fecha Inicio: " + fechaInicioFormateada + " - Fecha Fin: " + fechaFinFormateada + " - Usuario: " + reserva.usuario.getNombre() + "\n";
        }
        //Imprimir información reserva
        JOptionPane.showMessageDialog(null, mensaje);
    }

}
