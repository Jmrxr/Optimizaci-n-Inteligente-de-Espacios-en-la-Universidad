package SistemaReservasUniversidad.Reservas;

import SistemaReservasUniversidad.Usuarios.Usuario;
import java.util.ArrayList;
import java.util.Date;

public class Reserva {

    // Atributos
    private int identificador;
    private Date fechaInicio;
    private Date fechaFin;
    private Usuario usuario;

    // Lista para almacenar reservas
    private static ArrayList<Reserva> listaReservas = new ArrayList<>();

    // Constructor
    public Reserva(int identificador, Date fechaInicio, Date fechaFin, Usuario usuario) {
        this.identificador = identificador;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.usuario = usuario;
        listaReservas.add(this); // Agregar la reserva a la lista al crearla
    }

    // Método para registrar reserva
    public static void registrar(int identificador, Date fechaInicio, Date fechaFin, Usuario usuario) {

        // Verificar si ya existe una reserva con el mismo identificador
        for (Reserva reserva : listaReservas) {
            if (reserva.getIdentificador() == identificador) {
                // Si ya existe, no hacer nada y salir del método
                return;
            }
        }

        // Si no existe, crear una nueva reserva y agregarla a la lista
        Reserva nuevaReserva = new Reserva(identificador, fechaInicio, fechaFin, usuario);
        listaReservas.add(nuevaReserva);

    }

    //Atributo guarda identificacionUsuario 
    private static double identificacionUsuario;

    //Método para establecer identificación enviada como parametreo desde JFrame Login
    public void setIdentificacionUsuario(double identificacion) {
        identificacionUsuario = identificacion;
    }

    // Método para obtener la lista de reservas
    public static ArrayList<Reserva> getListaReservas() {
        return listaReservas;
    }

    //Método para obtener identificación
    public static double getIdentificacionUsuario() {
        return identificacionUsuario;
    }

    // Métodos de Acceso
    public int getIdentificador() {
        return identificador;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public Usuario getUsuario() {
        return usuario;
    }
}
