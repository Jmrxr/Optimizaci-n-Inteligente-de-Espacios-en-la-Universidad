package SistemaReservasUniversidad.Reservas;

import SistemaReservasUniversidad.Usuarios.Usuario;
import java.util.ArrayList;
import java.util.Date;

public class Reserva {

    // Atributos
    private int identificador;
    private Date fechaInicio;
    private Date fechaFin;
    private String observacion;
    private Usuario usuario;

    // Lista para almacenar reservas
    private static ArrayList<Reserva> listaReservas = new ArrayList<>();

    // Constructor
    public Reserva(int identificador, Date fechaInicio, Date fechaFin, String observacion, Usuario usuario) {
        this.identificador = identificador;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.usuario = usuario;
        this.observacion = observacion;
        listaReservas.add(this); // Agregar la reserva a la lista al crearla
    }

    // Método para registrar reserva
    public static void registrar(int identificador, Date fechaInicio, Date fechaFin, String observacion, Usuario usuario) {

        // Verificar si ya existe una reserva con el mismo identificador
        for (Reserva reserva : listaReservas) {
            if (reserva.getIdentificador() == identificador) {
                // Si ya existe, no hacer nada y salir del método
                return;
            }
        }
        // Si no existe, crear una nueva reserva y agregarla a la lista
        Reserva nuevaReserva = new Reserva(identificador, fechaInicio, fechaFin, observacion, usuario);
        listaReservas.add(nuevaReserva);

    }

    // Método para verificar si el aula está disponible en las fechas seleccionadas
    public static boolean reservaAulaDisponible(int idAula, Date fInicio, Date fFin) {
        for (Reserva reserva : Reserva.getListaReservas()) {
            if (reserva.getIdentificador() == idAula) {
                // Verificar si las fechas se solapan
                if (fInicio.before(reserva.getFechaFin()) && fFin.after(reserva.getFechaInicio())) {
                    return false; // Aula reservada en esas fechas
                }
            }
        }
        return true; // Aula disponible en las fechas seleccionadas
    }

    //Atributo guarda identificacionUsuario 
    private static double identificacionUsuario;

    //Método para establecer identificación enviada como parametreo desde JFrame Login
    public void setIdentificacionUsuario(double identificacion) {
        identificacionUsuario = identificacion;
    }

    // Método para obtener la lista de reservas
    public static ArrayList<Reserva> getListaReservas() {
        return listaReservas;
    }

    //Método para obtener identificación
    public static double getIdentificacionUsuario() {
        return identificacionUsuario;
    }

    // Métodos de Acceso
    public int getIdentificador() {
        return identificador;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public String getObservacion() {
        return observacion;
    }

    public Usuario getUsuario() {
        return usuario;
    }
}
