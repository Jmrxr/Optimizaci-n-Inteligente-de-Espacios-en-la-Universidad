package SistemaReservasUniversidad.Interfaces;

import java.awt.BorderLayout;
import java.time.LocalDate;

/**
 *
 * @author whoami
 */
public class Formulario extends javax.swing.JFrame {

    /*
     * Constructor de la clase Formulario. Inicializa los componentes del
     * formulario, establece la fecha actual y carga el contenido inicial.
     */
    public Formulario() {

        // Inicializa todos los componentes gráficos del formulario
        initComponents();

        // Establece la fecha actual en el componente de texto dateCalendar
        setDate();

        // Carga el contenido inicial en el panel principal
        initContent();

        //Inicializar credenciales usuerio
        initUser();
    }

    private void initUser() {

        /*Obtener la identificación del usuario
        double identificacionUsuario = Reserva.getIdentificacionUsuario();

        //LLamar método obtenerUsuarioID pasandole identificacionUsuario que inicio sección
        Usuario usuarioAutenticado = Usuario.obtenerUsuarioPorID(identificacionUsuario);

        //Llamar el usuario guardado en la lista
        String usuario = usuarioAutenticado.getNombre();
         */
        //Obtener nombre de usuario
        username.setText("Admin");

    }

    //Método para establecer la fecha actual en el componente de texto dateCalendar.
    private void setDate() {
        // Obtener la fecha actual del sistema
        LocalDate now = LocalDate.now();

        // Obtener el año, día y mes actual
        int year = now.getYear();
        int dia = now.getDayOfMonth();
        int month = now.getMonthValue();

        // Array de nombres de meses en español
        String[] meses = {"Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"};

        // Formatear la fecha actual y la muestra en el componente de texto dateCalendar
        dateCalendar.setText("Hoy es " + dia + " de " + meses[month - 1] + " de " + year);
    }

    private void initContent() {
        // Creamos una instancia del fondo deseado
        Fondo f1 = new Fondo();
        // Establecemos el tamaño y la posición del fondo
        f1.setSize(750, 430);
        f1.setLocation(0, 0);

        // Removemos todos los componentes del panel content
        content.removeAll();
        // Agregamos el contenido del fondo al panel content en el centro (CENTER)
        content.add(f1.getContentPane(), BorderLayout.CENTER);
        // Revalidamos y repintamos el panel content para mostrar los cambios
        content.revalidate();
        content.repaint();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenu3 = new javax.swing.JMenu();
        background = new javax.swing.JPanel();
        menu = new javax.swing.JPanel();
        mensaje1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        btnPrincipal = new javax.swing.JButton();
        btnUsuarios = new javax.swing.JButton();
        btnReservas = new javax.swing.JButton();
        header = new javax.swing.JPanel();
        mensaje = new javax.swing.JLabel();
        dateCalendar = new javax.swing.JLabel();
        content = new javax.swing.JPanel();
        username = new javax.swing.JLabel();
        logouser = new javax.swing.JLabel();
        salir = new javax.swing.JButton();

        jMenu3.setText("jMenu3");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        background.setBackground(new java.awt.Color(255, 255, 255));
        background.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        menu.setBackground(new java.awt.Color(0, 102, 204));

        mensaje1.setBackground(new java.awt.Color(255, 255, 255));
        mensaje1.setFont(new java.awt.Font("Dialog", 1, 20)); // NOI18N
        mensaje1.setForeground(new java.awt.Color(255, 255, 255));
        mensaje1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mensaje1.setText("SYSTEM");

        jSeparator1.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N

        btnPrincipal.setBackground(new java.awt.Color(45, 130, 255));
        btnPrincipal.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        btnPrincipal.setForeground(new java.awt.Color(255, 255, 255));
        btnPrincipal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/SistemaReservasUniversidad/Imagenes/home-outline.png"))); // NOI18N
        btnPrincipal.setText("    Principal");
        btnPrincipal.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 20, 1, 1, new java.awt.Color(0, 0, 0)));
        btnPrincipal.setBorderPainted(false);
        btnPrincipal.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnPrincipal.setHideActionText(true);
        btnPrincipal.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        btnPrincipal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrincipalActionPerformed(evt);
            }
        });

        btnUsuarios.setBackground(new java.awt.Color(45, 130, 255));
        btnUsuarios.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        btnUsuarios.setForeground(new java.awt.Color(255, 255, 255));
        btnUsuarios.setIcon(new javax.swing.ImageIcon(getClass().getResource("/SistemaReservasUniversidad/Imagenes/account-multiple.png"))); // NOI18N
        btnUsuarios.setText("    Usuarios");
        btnUsuarios.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 20, 1, 1, new java.awt.Color(0, 0, 0)));
        btnUsuarios.setBorderPainted(false);
        btnUsuarios.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnUsuarios.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        btnUsuarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUsuariosActionPerformed(evt);
            }
        });

        btnReservas.setBackground(new java.awt.Color(45, 130, 255));
        btnReservas.setFont(new java.awt.Font("Dialog", 1, 16)); // NOI18N
        btnReservas.setForeground(new java.awt.Color(255, 255, 255));
        btnReservas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/SistemaReservasUniversidad/Imagenes/calendar-multiple-check.png"))); // NOI18N
        btnReservas.setText("    Reservas");
        btnReservas.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 20, 1, 1, new java.awt.Color(0, 0, 0)));
        btnReservas.setBorderPainted(false);
        btnReservas.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnReservas.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        btnReservas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReservasActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout menuLayout = new javax.swing.GroupLayout(menu);
        menu.setLayout(menuLayout);
        menuLayout.setHorizontalGroup(
            menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(mensaje1, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addComponent(btnPrincipal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnReservas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnUsuarios, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, menuLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );
        menuLayout.setVerticalGroup(
            menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuLayout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addComponent(mensaje1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(54, 54, 54)
                .addComponent(btnPrincipal, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btnReservas, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btnUsuarios, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        background.add(menu, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 640));

        header.setBackground(new java.awt.Color(153, 153, 153));
        header.setPreferredSize(new java.awt.Dimension(744, 150));

        mensaje.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        mensaje.setForeground(new java.awt.Color(255, 255, 255));
        mensaje.setText("OPTIMIZACIÓN/ESPACIOS/UNIVERSIDAD");

        dateCalendar.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        dateCalendar.setForeground(new java.awt.Color(255, 255, 255));
        dateCalendar.setText("Fecha en tiempo real");

        javax.swing.GroupLayout headerLayout = new javax.swing.GroupLayout(header);
        header.setLayout(headerLayout);
        headerLayout.setHorizontalGroup(
            headerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(headerLayout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(headerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(mensaje, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(dateCalendar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(380, Short.MAX_VALUE))
        );
        headerLayout.setVerticalGroup(
            headerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(headerLayout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(mensaje)
                .addGap(18, 18, 18)
                .addComponent(dateCalendar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(43, Short.MAX_VALUE))
        );

        background.add(header, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 80, 780, 160));

        content.setBackground(new java.awt.Color(255, 255, 255));
        content.setPreferredSize(new java.awt.Dimension(700, 430));

        javax.swing.GroupLayout contentLayout = new javax.swing.GroupLayout(content);
        content.setLayout(contentLayout);
        contentLayout.setHorizontalGroup(
            contentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 730, Short.MAX_VALUE)
        );
        contentLayout.setVerticalGroup(
            contentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 360, Short.MAX_VALUE)
        );

        background.add(content, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 260, 730, 360));

        username.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        username.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        username.setText("USER");
        background.add(username, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 20, 200, 40));

        logouser.setFont(new java.awt.Font("Dialog", 1, 20)); // NOI18N
        logouser.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        logouser.setIcon(new javax.swing.ImageIcon(getClass().getResource("/SistemaReservasUniversidad/Imagenes/userlogo.png"))); // NOI18N
        background.add(logouser, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 0, 60, 80));

        salir.setBackground(new java.awt.Color(255, 255, 255));
        salir.setFont(new java.awt.Font("Dialog", 0, 16)); // NOI18N
        salir.setText("Salir");
        salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salirActionPerformed(evt);
            }
        });
        background.add(salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 20, -1, 40));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(background, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(background, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnPrincipalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrincipalActionPerformed
        // Creamos una instancia del fondo deseado
        Fondo f1 = new Fondo();
        // Establecemos el tamaño y la posición del fondo
        f1.setSize(750, 430);
        f1.setLocation(0, 0);

        // Removemos todos los componentes del panel content
        content.removeAll();
        // Agregamos el contenido del fondo al panel content en el centro (CENTER)
        content.add(f1.getContentPane(), BorderLayout.CENTER);
        // Revalidamos y repintamos el panel content para mostrar los cambios
        content.revalidate();
        content.repaint();

    }//GEN-LAST:event_btnPrincipalActionPerformed

    private void salirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salirActionPerformed
        //Cerrar el formulario
        this.dispose();

        //Crear instancia del Login
        Login lg = new Login();
        lg.setLocationRelativeTo(null);
        lg.setVisible(true);
    }//GEN-LAST:event_salirActionPerformed

    private void btnReservasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReservasActionPerformed
        //Creamos una instancia del JFrame Reservation         
        Reservation r1 = new Reservation();
        r1.setSize(730, 360);
        r1.setLocation(0, 0);

        /* Obtén el JMenuBar del JFrame Principal
        JMenuBar menuBar = u1.getJMenuBar();*/
        // Remueve todos los componentes del panel content
        content.removeAll();

        /*Agrega el JMenuBar al panel content
        content.add(menuBar, BorderLayout.NORTH);*/
        // Agrega el panel raíz del JFrame Principal al panel content
        content.add(r1.getContentPane(), BorderLayout.CENTER);

        // Revalida y repinta el panel content para mostrar los cambios
        content.revalidate();
        content.repaint();
    }//GEN-LAST:event_btnReservasActionPerformed

    private void btnUsuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUsuariosActionPerformed
        //Creamos una instancia del JFrame User         
        User u1 = new User();
        u1.setSize(730, 360);
        u1.setLocation(0, 0);

        /* Obtén el JMenuBar del JFrame Principal
        JMenuBar menuBar = u1.getJMenuBar();*/
        // Remueve todos los componentes del panel content
        content.removeAll();

        /*Agrega el JMenuBar al panel content
        content.add(menuBar, BorderLayout.NORTH);*/
        // Agrega el panel raíz del JFrame Principal al panel content
        content.add(u1.getContentPane(), BorderLayout.CENTER);

        // Revalida y repinta el panel content para mostrar los cambios
        content.revalidate();
        content.repaint();
    }//GEN-LAST:event_btnUsuariosActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Formulario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel background;
    private javax.swing.JButton btnPrincipal;
    private javax.swing.JButton btnReservas;
    private javax.swing.JButton btnUsuarios;
    private javax.swing.JPanel content;
    private javax.swing.JLabel dateCalendar;
    private javax.swing.JPanel header;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel logouser;
    private javax.swing.JLabel mensaje;
    private javax.swing.JLabel mensaje1;
    private javax.swing.JPanel menu;
    private javax.swing.JButton salir;
    private javax.swing.JLabel username;
    // End of variables declaration//GEN-END:variables

}
