package SistemaReservasUniversidad.Interfaces;

import SistemaReservasUniversidad.Reservas.Reserva;
import SistemaReservasUniversidad.Usuarios.Usuario;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author whoami
 */
public class Reservation extends javax.swing.JFrame {

    public Reservation() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        identificadorAula = new javax.swing.JTextField();
        btnRealizar = new javax.swing.JButton();
        jSpinnerInicio = new javax.swing.JSpinner();
        jSpinnerFin = new javax.swing.JSpinner();
        jLabel3 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        btnMostrarReservas = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTabbedPane2.setBackground(new java.awt.Color(153, 153, 153));
        jTabbedPane2.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        jLabel1.setText("RESERVAR AULAS INFORMATICAS");

        jLabel7.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N
        jLabel7.setText("Fecha inicio:");

        jLabel8.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N
        jLabel8.setText("Fecha fin:");

        identificadorAula.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N

        btnRealizar.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        btnRealizar.setText("Realizar");
        btnRealizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRealizarActionPerformed(evt);
            }
        });

        jSpinnerInicio.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N
        jSpinnerInicio.setModel(new javax.swing.SpinnerDateModel());

        jSpinnerFin.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N
        jSpinnerFin.setModel(new javax.swing.SpinnerDateModel());

        jLabel3.setFont(new java.awt.Font("Dialog", 0, 13)); // NOI18N
        jLabel3.setText("Número de aula:              ");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(265, 265, 265)
                .addComponent(jLabel1)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(69, 69, 69)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel7))
                        .addGap(116, 116, 116))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel3)
                        .addGap(40, 40, 40)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSpinnerInicio, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jSpinnerFin, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(63, 63, 63)
                        .addComponent(btnRealizar))
                    .addComponent(identificadorAula, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel1)
                .addGap(32, 32, 32)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(identificadorAula, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(jSpinnerInicio, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(jSpinnerFin, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addComponent(btnRealizar)))
                .addContainerGap(120, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Espacios Fisicos", jPanel1);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        btnMostrarReservas.setFont(new java.awt.Font("Dialog", 1, 13)); // NOI18N
        btnMostrarReservas.setText("Mostrar reservas");
        btnMostrarReservas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarReservasActionPerformed(evt);
            }
        });

        jTable.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Fecha inicio", "Fecha fin", "Solicitante", "Aula"
            }
        ));
        jScrollPane2.setViewportView(jTable);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnMostrarReservas)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 553, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(40, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(btnMostrarReservas)
                .addGap(28, 28, 28)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(41, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Consultar", jPanel2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane2)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane2)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void btnRealizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRealizarActionPerformed

        int idAula = Integer.parseInt(identificadorAula.getText());
        Date fInicio = (Date) jSpinnerInicio.getValue();
        Date fFin = (Date) jSpinnerFin.getValue();
        double identificacionUsuario = Reserva.getIdentificacionUsuario();

        Usuario usuarioAutenticado = Usuario.obtenerUsuarioPorID(identificacionUsuario);

        if (usuarioAutenticado != null) {
            // Verificar si el aula está reservada en las fechas seleccionadas
            if (reservaAulaDisponible(idAula, fInicio, fFin)) {
                // Si el aula está disponible, registrar la reserva
                Reserva.registrar(idAula, fInicio, fFin, usuarioAutenticado);

                // Mostrar los datos de la reserva recién guardada en un JOptionPane
                String reservaInfo = "Fecha de inicio: " + new SimpleDateFormat("yyyy-MM-dd HH:mm").format(fInicio) + "\n"
                        + "Fecha de fin: " + new SimpleDateFormat("yyyy-MM-dd HH:mm").format(fFin) + "\n"
                        + "Solicitante: " + usuarioAutenticado.getNombre() + "\n"
                        + "Número de aula: " + idAula + "\n";

                JOptionPane.showMessageDialog(null, reservaInfo, "Reserva guardada", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "El aula ya está reservada en las fechas seleccionadas", "Error de Reserva", JOptionPane.ERROR_MESSAGE);
            }
        }

    }//GEN-LAST:event_btnRealizarActionPerformed

    // Método para verificar si el aula está disponible en las fechas seleccionadas
    private boolean reservaAulaDisponible(int idAula, Date fInicio, Date fFin) {
        for (Reserva reserva : Reserva.getListaReservas()) {
            if (reserva.getIdentificador() == idAula) {
                // Verificar si las fechas se solapan
                if (fInicio.before(reserva.getFechaFin()) && fFin.after(reserva.getFechaInicio())) {
                    return false; // Aula reservada en esas fechas
                }
            }
        }
        return true; // Aula disponible en las fechas seleccionadas
    }

    private void btnMostrarReservasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarReservasActionPerformed

        // Crear o acceder al modelo de la tabla
        DefaultTableModel model = (DefaultTableModel) jTable.getModel();

        // Limpiar el modelo de tabla antes de agregar nuevos datos
        model.setRowCount(0);

        // Recorrer la lista de reservas
        for (Reserva reserva : Reserva.getListaReservas()) {
            // Verificar si la reserva ya ha sido agregada al modelo de tabla
            boolean reservaExiste = false;
            for (int i = 0; i < model.getRowCount(); i++) {
                if ((int) model.getValueAt(i, 3) == reserva.getIdentificador()) {
                    reservaExiste = true;
                    break;
                }
            }

            // Si la reserva no ha sido agregada, agregarla al modelo de tabla
            if (!reservaExiste) {
                // Verificar si las fechas no son nulas antes de formatearlas
                if (reserva.getFechaInicio() != null && reserva.getFechaFin() != null) {
                    // Preparar los datos de la reserva
                    Object[] rowData = {
                        new SimpleDateFormat("yyyy-MM-dd HH:mm").format(reserva.getFechaInicio()),
                        new SimpleDateFormat("yyyy-MM-dd HH:mm").format(reserva.getFechaFin()),
                        reserva.getUsuario().getNombre(),
                        reserva.getIdentificador()
                    };

                    // Agregar los datos de la reserva al modelo de tabla
                    model.addRow(rowData);
                }
            }
        }

        // Asignar el modelo de tabla actualizado al JTable
        jTable.setModel(model);
    }//GEN-LAST:event_btnMostrarReservasActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Reservation().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnMostrarReservas;
    private javax.swing.JButton btnRealizar;
    private javax.swing.JTextField identificadorAula;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSpinner jSpinnerFin;
    private javax.swing.JSpinner jSpinnerInicio;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTable jTable;
    // End of variables declaration//GEN-END:variables
}
