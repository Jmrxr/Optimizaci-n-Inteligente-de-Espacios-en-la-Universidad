package SistemaReservasUniversidad.Interfaces;

import SistemaReservasUniversidad.Reservas.Reserva;
import SistemaReservasUniversidad.Usuarios.Usuario;
import java.awt.Color;
import javax.swing.JOptionPane;

/**
 *
 * @author whoami
 */
public class Login extends javax.swing.JFrame {

    /**
     * Creates new form Log
     */
    public Login() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bg = new javax.swing.JPanel();
        favicon = new javax.swing.JLabel();
        userLabel = new javax.swing.JLabel();
        userTxt = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        userLabel1 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        passTxt = new javax.swing.JPasswordField();
        jPanel1 = new javax.swing.JPanel();
        logo = new javax.swing.JLabel();
        logonombre = new javax.swing.JLabel();
        btnIniciar = new javax.swing.JButton();
        btnRegistrar1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        bg.setBackground(new java.awt.Color(255, 255, 255));
        bg.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        favicon.setFont(new java.awt.Font("Dialog", 1, 20)); // NOI18N
        favicon.setText("LOGIN");
        bg.add(favicon, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, -1, -1));

        userLabel.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        userLabel.setText("USUARIO");
        bg.add(userLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 120, 80, 30));

        userTxt.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        userTxt.setForeground(new java.awt.Color(153, 153, 153));
        userTxt.setText("Número de identificación");
        userTxt.setBorder(null);
        userTxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                userTxtMousePressed(evt);
            }
        });
        bg.add(userTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 150, 337, 28));

        jSeparator1.setForeground(new java.awt.Color(0, 0, 0));
        bg.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 190, 337, -1));

        userLabel1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        userLabel1.setText("CONTRASEÑA");
        bg.add(userLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 230, 130, 30));

        jSeparator2.setForeground(new java.awt.Color(0, 0, 0));
        bg.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 300, 344, -1));

        passTxt.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        passTxt.setForeground(new java.awt.Color(153, 153, 153));
        passTxt.setText("contraseña");
        passTxt.setBorder(null);
        passTxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                passTxtMousePressed(evt);
            }
        });
        bg.add(passTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 270, 344, 28));

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        logo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/SistemaReservasUniversidad/Imagenes/Loading.png"))); // NOI18N
        jPanel1.add(logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, 270, 190));

        logonombre.setFont(new java.awt.Font("Dialog", 1, 20)); // NOI18N
        logonombre.setForeground(new java.awt.Color(255, 255, 255));
        logonombre.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel1.add(logonombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 167, 280, -1));

        bg.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 0, 268, 453));

        btnIniciar.setBackground(new java.awt.Color(45, 130, 255));
        btnIniciar.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        btnIniciar.setForeground(new java.awt.Color(255, 255, 255));
        btnIniciar.setText("INICIAR");
        btnIniciar.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        btnIniciar.setBorderPainted(false);
        btnIniciar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnIniciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIniciarActionPerformed(evt);
            }
        });
        bg.add(btnIniciar, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 350, 160, 40));

        btnRegistrar1.setBackground(new java.awt.Color(45, 130, 255));
        btnRegistrar1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        btnRegistrar1.setForeground(new java.awt.Color(255, 255, 255));
        btnRegistrar1.setText("CREAR TU CUENTA");
        btnRegistrar1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnRegistrar1.setBorderPainted(false);
        btnRegistrar1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnRegistrar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegistrar1ActionPerformed(evt);
            }
        });
        bg.add(btnRegistrar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 350, 160, 40));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(bg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void userTxtMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_userTxtMousePressed
        // Establece el texto de userTxt como una cadena vacía
        userTxt.setText("");

        // Establece el color de primer plano de userTxt como negro
        userTxt.setForeground(Color.black);

    }//GEN-LAST:event_userTxtMousePressed

    private void passTxtMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_passTxtMousePressed

        // Establece el texto de passTxt como una cadena vacía
        passTxt.setText("");

        // Establece el color de primer plano de passTxt como negro
        passTxt.setForeground(Color.black);

    }//GEN-LAST:event_passTxtMousePressed

    private void btnIniciarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIniciarActionPerformed

        String var = String.valueOf(passTxt.getPassword());

        if ((userTxt.getText().isEmpty()) || (var.isEmpty())) {
            JOptionPane.showMessageDialog(null, "Por favor, ingrese primero Usuario y contraseña antes de iniciar sesión.");
        } else {

            //Obtener credenciales de usuario
            Double user = Double.parseDouble(userTxt.getText());
            Double pass = Double.parseDouble(String.valueOf(passTxt.getPassword()));

            //Llamar metodo autenticar de Log para autenticar usuario
            Usuario usuarioAutenticado = Usuario.autenticar(user, pass);

            // Crear una instancia de Reserva
            Reserva reserva = new Reserva(0, null, null, usuarioAutenticado);

            // Enviar la identificación del usuario a la clase Reserva
            reserva.setIdentificacionUsuario(user);

            //Validar usuario
            if (usuarioAutenticado != null) {
                //Crear instacia de interfa formulario
                Formulario f = new Formulario();
                f.setLocationRelativeTo(null);
                f.setVisible(true); //Hacer visible la ventana
                this.dispose();//Cerrar ventana login 

            } else {
                JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos\npor favor intentalo de nuevo.");
            }
        }
    }//GEN-LAST:event_btnIniciarActionPerformed

    private void btnRegistrar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistrar1ActionPerformed

        //Restablecer campos Login
        userTxt.setForeground(new Color(153, 153, 153));
        userTxt.setText("Número de identificación");
        passTxt.setForeground(new Color(153, 153, 153));
        passTxt.setText("**********");
        //Crear una instancia de la clase NewCuenta
        Cuenta nc = new Cuenta();
        nc.setLocationRelativeTo(null);
        nc.setVisible(true);

    }//GEN-LAST:event_btnRegistrar1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel bg;
    private javax.swing.JButton btnIniciar;
    private javax.swing.JButton btnRegistrar1;
    private javax.swing.JLabel favicon;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JLabel logo;
    private javax.swing.JLabel logonombre;
    private javax.swing.JPasswordField passTxt;
    private javax.swing.JLabel userLabel;
    private javax.swing.JLabel userLabel1;
    private javax.swing.JTextField userTxt;
    // End of variables declaration//GEN-END:variables
}
