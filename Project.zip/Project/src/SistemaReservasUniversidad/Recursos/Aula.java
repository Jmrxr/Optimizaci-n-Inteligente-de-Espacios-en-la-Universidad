package SistemaReservasUniversidad.Recursos;

public class Aula {

}
