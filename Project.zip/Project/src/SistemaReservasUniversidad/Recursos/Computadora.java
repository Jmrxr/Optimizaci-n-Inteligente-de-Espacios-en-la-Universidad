
package SistemaReservasUniversidad.Recursos;

/**
 *
 * @author whoami
 */
public class Computadora {
    
}
