package SistemaReservasUniversidad.Usuarios;

import java.util.ArrayList;

public class Usuario {

    //Atributos
    private double identificacion;
    private String nombre;
    private String cargo;
    private String correo;

    //Lista guardar usuarios
    public static ArrayList<Usuario> listaUsuarios = new ArrayList<>();

    //Constructor
    public Usuario(double identificacion, String nombre, String cargo, String correo) {
        this.identificacion = identificacion;
        this.nombre = nombre;
        this.cargo = cargo;
        this.correo = correo;
        listaUsuarios.add(this);//Agregar el nuevo usuario a la lista de usuarios
    }

    //Métodos autenticar usuario
    public static Usuario autenticar(double identificacion, double contraseña) {

        //Buscar usuario en la lista
        for (Usuario usuario : listaUsuarios) {
            if ((usuario.getIdentificacion() == identificacion) && (usuario.getIdentificacion() == contraseña)) {
                return usuario;//Devuelve el usuario autenticado
            }
        }
        return null;//Devuelve usuario no autenticado
    }

    //Mètodo registrar nuevo usuario
    public static void registrar(double identificacion, String nombre, String cargo, String correo) {
        //Crear un nuevo usuario y agregarlo a la lista
        Usuario nuevoUsuario = new Usuario(identificacion, nombre, cargo, correo);
        listaUsuarios.add(nuevoUsuario); // Agregar el nuevo usuario a la lista de usuarios

    }

    //Método para obtener el usuario por ID
    public static Usuario obtenerUsuarioPorID(double idUser) {
        for (Usuario usuario : listaUsuarios) {
            if (usuario.getIdentificacion() == idUser) {
                return usuario;
            }
        }
        return null;
    }

    //Métodos Getters
    public double getIdentificacion() {
        return identificacion;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCargo() {
        return cargo;
    }

    public String getCorreo() {
        return correo;
    }

}